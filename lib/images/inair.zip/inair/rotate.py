
#-*- coding: UTF-8 -*-
from PIL import Image
import os

img_path = 'F:/Documents/Code/web/vcqhaoc/inair/0.png'            # 原始图片路径
output_path = 'F:/Documents/Code/web/vcqhaoc/inair/'     # 保存路径

for i in range(1, 361):
    img = Image.open(img_path)
    im_rotate = img.rotate(i-(2*i))           # 指定逆时针旋转的角度
    im_rotate.save(output_path + str(i) + '.png')  # 保存旋转后的图片
